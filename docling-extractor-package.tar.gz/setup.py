"""
Setup script for docling-extractor package
"""
from setuptools import setup, find_packages
from pathlib import Path

# Read README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="docling-extractor",
    version="1.0.0",
    author="Nalini Panwar",
    author_email="panwarnalini@gmail.com",
    description="Production-grade document extraction for Databricks with fallback chains",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/panwarnalini-hub/clinical-doc-pipelines",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "PyMuPDF>=1.23.0",
        "pdfplumber>=0.10.0",
        "Pillow>=10.0.0",
        "pytesseract>=0.3.10",
    ],
    extras_require={
        "docling": [
            "docling>=1.0.0",
            "docling-core>=1.0.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "docling-extract=docling_extractor.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
