# Build & Release Guide for docling-extractor

## Quick Build

```bash
# Install build tools
pip install build twine

# Build wheel and source distribution
python -m build

# Output will be in dist/:
# - docling_extractor-1.0.0-py3-none-any.whl
# - docling-extractor-1.0.0.tar.gz
```

## Upload to GitHub

### Option 1: As a Release Asset

1. Go to your repo: https://github.com/panwarnalini-hub/clinical-doc-pipelines
2. Click "Releases" → "Create a new release"
3. Tag: `v1.0.0`
4. Title: `Docling Extractor v1.0.0`
5. Description:
   ```
   Production-grade document extraction library for Databricks
   
   Features:
   - Smart PDF detection (scanned vs digital)
   - Fallback extraction chain
   - Databricks optimized
   - Timeout protection
   
   Install: `pip install https://github.com/panwarnalini-hub/clinical-doc-pipelines/releases/download/v1.0.0/docling_extractor-1.0.0-py3-none-any.whl`
   ```
6. Attach the `.whl` file from `dist/`
7. Publish release

### Option 2: Publish to PyPI (Public)

```bash
# Test on TestPyPI first
twine upload --repository testpypi dist/*

# Install from TestPyPI to verify
pip install --index-url https://test.pypi.org/simple/ docling-extractor

# If everything works, upload to real PyPI
twine upload dist/*

# Users can now: pip install docling-extractor
```

### Option 3: Private PyPI Server

If your company has a private PyPI server:

```bash
twine upload --repository-url https://your-company-pypi.com dist/*
```

## Install from Wheel

### Direct from file
```bash
pip install /path/to/docling_extractor-1.0.0-py3-none-any.whl
```

### From GitHub Release
```bash
pip install https://github.com/panwarnalini-hub/clinical-doc-pipelines/releases/download/v1.0.0/docling_extractor-1.0.0-py3-none-any.whl
```

### From Git (Development)
```bash
pip install git+https://github.com/panwarnalini-hub/clinical-doc-pipelines.git#subdirectory=docling-extractor
```

## Databricks Installation

### Method 1: Upload Wheel to DBFS

```bash
# Upload wheel to DBFS
databricks fs cp dist/docling_extractor-1.0.0-py3-none-any.whl dbfs:/FileStore/wheels/

# Install on cluster
%pip install /dbfs/FileStore/wheels/docling_extractor-1.0.0-py3-none-any.whl
```

### Method 2: Cluster Library

1. Go to your cluster
2. Libraries → Install New
3. Library Source: "Upload" or "DBFS/S3"
4. Upload the wheel file
5. Install

### Method 3: Init Script + Requirements

Create `cluster-init.sh`:
```bash
#!/bin/bash
pip install https://github.com/panwarnalini-hub/clinical-doc-pipelines/releases/download/v1.0.0/docling_extractor-1.0.0-py3-none-any.whl
```

## Version Bumping

When releasing a new version:

1. Update version in:
   - `setup.py`
   - `pyproject.toml`
   - `docling_extractor/__init__.py`

2. Update CHANGELOG.md

3. Build new wheel:
   ```bash
   python -m build
   ```

4. Create new GitHub release with updated wheel

## Testing Before Release

```bash
# Install in development mode
pip install -e .

# Run tests (if you have them)
pytest tests/

# Try importing
python -c "from docling_extractor import extract_single_document; print('OK')"
```

## Troubleshooting

### "Module not found" after install

Check installation:
```bash
pip show docling-extractor
```

Verify imports:
```python
import docling_extractor
print(docling_extractor.__version__)
```

### Databricks import issues

Make sure init script ran:
```bash
%sh
tesseract --version
pandoc --version
```

Install with extras:
```python
%pip install docling-extractor[docling]
```
