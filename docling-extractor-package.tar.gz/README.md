# Docling Extractor

Production-grade document extraction library for Databricks with intelligent fallback chains.

## Features

- **Smart PDF Detection**: Automatically detects scanned vs digital PDFs
- **Fallback Chain**: Multiple extraction methods ensure robustness
- **Databricks Optimized**: Handles read-only site-packages and cluster constraints
- **Timeout Protection**: Hard kills hung processes after 90 seconds
- **Structured Output**: Returns pages, sections, images, tables, and formulas

## Extraction Strategy

### Digital PDFs
```
Docling → PyMuPDF → pdfplumber → raw_text
```

### Scanned PDFs
```
Tesseract OCR → PyMuPDF
```

## Installation

```bash
# Basic installation
pip install docling-extractor

# With Docling support (recommended)
pip install docling-extractor[docling]

# Development installation
pip install docling-extractor[dev]
```

## Usage

### Basic Extraction

```python
from docling_extractor import extract_single_document

result = extract_single_document(
    input_path="/path/to/document.pdf",
    output_dir="/path/to/output",
    document_id="doc_001"
)

# Access extracted data
pages = result["pages"]
sections = result["sections"]
images = result["images"]
tables = result["tables"]
```

### Check if PDF is Scanned

```python
from docling_extractor import is_scanned_pdf

if is_scanned_pdf("/path/to/document.pdf"):
    print("This PDF requires OCR")
else:
    print("This is a digital PDF")
```

### Direct Extractor Usage

```python
from docling_extractor import DoclingExtractor

extractor = DoclingExtractor(output_dir="/tmp/output")
result = extractor.extract(
    path="/path/to/document.pdf",
    doc_id="doc_001"
)
```

## Databricks Integration

### Install on Cluster

```bash
# Create init script
cat > /dbfs/databricks/scripts/install_doc_tools.sh << 'EOF'
#!/bin/bash
apt-get update
apt-get install -y pandoc tesseract-ocr
echo "Installed pandoc + tesseract on all nodes"
EOF

# Configure cluster to use init script
# Cluster > Advanced Options > Init Scripts > /dbfs/databricks/scripts/install_doc_tools.sh
```

### Install Python Package

```python
# Install on cluster
%pip install docling-extractor[docling]
```

### Use in Spark Job

```python
from pyspark.sql.functions import udf
from pyspark.sql.types import StructType, ArrayType, StringType
from docling_extractor import extract_single_document

def extract_document_udf(path: str, doc_id: str) -> dict:
    """UDF wrapper for document extraction"""
    return extract_single_document(
        input_path=path,
        output_dir="/dbfs/tmp/extraction_output",
        document_id=doc_id
    )

# Register UDF
spark.udf.register("extract_doc", extract_document_udf)

# Use in DataFrame
df = spark.table("bronze_documents")
extracted_df = df.selectExpr(
    "document_id",
    "extract_doc(file_path, document_id) as extraction"
)
```

## Output Schema

```python
{
    "registry": {
        "protocol_id": str,
        "document_id": str,
        "processing_status": str,  # "success" or "failed"
        "page_count": int,
        "tools_used": List[str],  # ["docling", "pymupdf", etc.]
        "processed_at": str,
        "error_message": str
    },
    "pages": [
        {
            "document_id": str,
            "page_number": int,
            "text": str,
            "source_path": str
        }
    ],
    "sections": [
        {
            "section_id": str,
            "document_id": str,
            "page_number": int,
            "sequence_number": int,
            "section_type": str,
            "content_text": str,
            "heading_level": Optional[int],
            "bbox_x0": Optional[float],
            "bbox_y0": Optional[float],
            "bbox_x1": Optional[float],
            "bbox_y1": Optional[float]
        }
    ],
    "images": [...],
    "tables": [...],
    "formulas": [...]
}
```

## Configuration

### Timeout Settings

```python
# Default: 90 seconds
# Adjust in code if needed for large documents
DOCLING_TIMEOUT_SECONDS = 120
```

### Scanned PDF Detection

```python
# Default: checks first 3 pages
# Considers scanned if <100 chars/page and has images
is_scanned = is_scanned_pdf(path, sample_pages=5)
```

## Error Handling

The library uses a fallback chain - if one extraction method fails, it tries the next:

```python
result = extract_single_document(...)

if result["registry"]["processing_status"] == "failed":
    print(f"Error: {result['registry']['error_message']}")
else:
    print(f"Success using: {result['registry']['tools_used']}")
```

## Development

### Build from Source

```bash
git clone https://github.com/panwarnalini-hub/clinical-doc-pipelines.git
cd clinical-doc-pipelines/docling-extractor
pip install -e .[dev]
```

### Run Tests

```bash
pytest tests/
```

### Build Wheel

```bash
python setup.py bdist_wheel
# Wheel will be in dist/
```

## Requirements

### Core Dependencies
- PyMuPDF >= 1.23.0
- pdfplumber >= 0.10.0  
- Pillow >= 10.0.0
- pytesseract >= 0.3.10

### Optional Dependencies
- docling >= 1.0.0 (for advanced digital PDF extraction)
- docling-core >= 1.0.0

### System Dependencies (Databricks/Linux)
- tesseract-ocr
- pandoc

## License

MIT License - See LICENSE file for details.

## Author

**Nalini Panwar**  
Lead Data Engineer  
[GitHub](https://github.com/panwarnalini-hub)

## Contributing

Contributions welcome! Please open an issue or PR on GitHub.

## Changelog

### 1.0.0 (2025-12-29)
- Initial release
- Support for digital and scanned PDFs
- Fallback chain architecture
- Databricks optimization
- Timeout protection
