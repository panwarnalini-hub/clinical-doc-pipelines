"""
Docling Extractor - Production-grade document extraction for Databricks

Extracts structured data from PDFs using a fallback chain:
- DIGITAL PDFs: Docling → PyMuPDF → pdfplumber → raw_text
- SCANNED PDFs: Tesseract → PyMuPDF
"""

__version__ = "1.0.0"
__author__ = "Nalini Panwar"

from .extractor import (
    DoclingExtractor,
    TesseractExtractor,
    extract_single_document,
    is_scanned_pdf,
)

__all__ = [
    "DoclingExtractor",
    "TesseractExtractor", 
    "extract_single_document",
    "is_scanned_pdf",
]
